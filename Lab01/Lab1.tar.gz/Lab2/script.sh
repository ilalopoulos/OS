#!/bin/bash
current_time=`date +%s`
let current_time2=current_time+current_time
echo "Current time (epoch): " $current_time
echo "Double Current time : " $current_time2
for ((i=1;i<=20;i++)); do echo $i; done
